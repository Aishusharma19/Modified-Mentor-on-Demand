package com.repository;



import org.springframework.data.repository.CrudRepository;

import com.entity.Tech;




public interface TechRepo extends CrudRepository< Tech, Integer> {

}
