package com.repository;



import org.springframework.data.repository.CrudRepository;


import com.entity.paymentCom;




public interface paymentComRepo extends CrudRepository< paymentCom, Integer> {

}
