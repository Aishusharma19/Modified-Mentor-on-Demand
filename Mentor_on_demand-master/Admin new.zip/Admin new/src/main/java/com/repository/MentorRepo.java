package com.repository;



import org.springframework.data.repository.CrudRepository;

import com.entity.Mentor;




public interface MentorRepo extends CrudRepository<Mentor, Integer> {

}
