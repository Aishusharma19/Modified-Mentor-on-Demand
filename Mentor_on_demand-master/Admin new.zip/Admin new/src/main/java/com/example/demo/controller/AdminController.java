package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.bind.annotation.*;

import com.example.demo.pojo.AdminCredentials;
import com.example.demo.pojo.Technology;
import com.example.demo.repo.TechRepo;
import com.example.demo.service.AdminService;

@EnableEurekaClient
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AdminController {

	@Autowired
	AdminService adminService;
	TechRepo techrepo;
	
	@RequestMapping("/admin/{userName}")
    public AdminCredentials adminName(@PathVariable String userName){
		System.out.println(userName);
		System.out.println(adminService.adminName(userName));
        return adminService.adminName(userName);
    }
	@RequestMapping("/admin/technology")
    public List<Technology> tech(){
        return adminService.getTechnology();
    }
	
	   @RequestMapping(method=RequestMethod.DELETE,value="/admin/technology/{id}")
	    public void deleteTraining(@PathVariable Long id){
	        adminService.deleteTraining(id);
	    }
	
	   @RequestMapping(method= RequestMethod.POST,value="/admin/tech")
	    public @ResponseBody  String addTraining(@RequestBody Technology t) {
	        adminService.addTech(t);
	        return "stored";
	    }
	
	
	
}
