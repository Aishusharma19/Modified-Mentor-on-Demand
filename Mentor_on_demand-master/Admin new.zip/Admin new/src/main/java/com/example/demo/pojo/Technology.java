package com.example.demo.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Technology")

public class Technology {
	@Id
	private Long techId;
	private String TechnologyName;
	
	
	
	public Technology() {}
	


	public Technology(Long techId, String technologyName) {
		super();
		this.techId = techId;
		TechnologyName = technologyName;
	}



	public Long getTechId() {
		return techId;
	}


	public void setTechId(Long techId) {
		this.techId = techId;
	}


	public String getTechnologyName() {
		return TechnologyName;
	}


	public void setTechnologyName(String technologyName) {
		TechnologyName = technologyName;
	};
	
	
	
	
	

}
