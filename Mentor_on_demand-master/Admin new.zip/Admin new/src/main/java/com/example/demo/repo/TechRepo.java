package com.example.demo.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.pojo.AdminCredentials;
import com.example.demo.pojo.Technology;

public interface TechRepo extends CrudRepository<Technology, Long> {

}
