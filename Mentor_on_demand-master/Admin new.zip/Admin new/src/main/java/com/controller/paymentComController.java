package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.entity.paymentCom;
import com.repository.paymentComRepo;
import com.service.paymentComService;


@RestController
public class paymentComController {
	@Autowired

	private paymentComService ms;

	@RequestMapping("/paymentCom")
	public List<paymentCom> getpaymentCom() {
		return ms.getpaymentCom();
	}

	@RequestMapping("/paymentCom/{id}")
	public paymentCom getpaymentCom(@PathVariable Integer id) {

		return ms.getpaymentCom(id);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/paymentCom")

	public void addpaymentCom(@RequestBody paymentCom s) {
		ms.addpaymentCom(s);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/paymentCom/{id}")
	public void updatepaymentCom(@RequestBody paymentCom s, @PathVariable Integer id) {
		ms.updatepaymentCom(s, id);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/paymentCom/{id}")
	public void deletepaymentCom(@PathVariable Integer id) {
		ms.deletepaymentCom(id);
	}

}


