package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity

public class Mentor {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name="mentorid")
	private Integer id;
	@Column(name="mentorname")
	private String name;
	
	
	public Mentor() {
		
	}                                                        
	
	
	
	
	
	
	
	
	public Mentor(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
